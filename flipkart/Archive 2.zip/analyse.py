import json
s = "12AB"
print s.lower()