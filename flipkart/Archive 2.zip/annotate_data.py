import nltk
import csv
import json
import pickle
infile = open("headphone_inv_dict.json",'rb')
inv_diction = json.load(infile)
list_tokens = []
list_labels = []
with open("headphone_1454324853776_catalog.csv") as csvfile:
	spamreader = csv.DictReader(csvfile)
	i = 0
	for row in spamreader:
		desc = row['description'].lower()
		tokens = nltk.word_tokenize(desc.decode('utf-8'))
		itokens = []
		labels = []
		for index in range(len(tokens)):
			if tokens[index] in inv_diction:
				labels.append(inv_diction[tokens[index]].keys()[0])
				itokens.append(tokens[index])
			else:
				if index == len(tokens)-1:
					break
				two_gram = tokens[index]+" "+tokens[index+1]
				two_gram_2 = tokens[index]+"$$"+tokens[index+1]
				if two_gram in inv_diction:
					labels.append(inv_diction[two_gram].keys()[0])
					itokens.append(two_gram)
					index = index+1
					continue
				if two_gram_2 in inv_diction:
					labels.append(inv_diction[two_gram_2].keys()[0])
					itokens.append(two_gram_2)
					index = index+1
				else:
					if index > len(tokens)-3:
						break
					three_gram = tokens[index]+" "+tokens[index+1]+" "+tokens[index+2]
					if three_gram in inv_diction:
						labels.append(inv_diction[three_gram].keys()[0])
						itokens.append(three_gram)
						index = index+2
					else:
						itokens.append(tokens[index])
						labels.append("NA")

		list_tokens.append(itokens)
		list_labels.append(labels)
outfile = open("list_tokens",'wb')
pickle.dump(list_tokens, outfile)
outfile.close()
outfile = open("list_labels",'wb')
pickle.dump(list_labels, outfile)