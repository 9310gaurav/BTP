import csv
import json
diction = {}
list_of = ['brand','color','model_id','headphone_jack','cord_length','wired_wireless','headset_design','headset_type']
for item in list_of:
	diction[item] = {}
with open("headphone_1454324853776_catalog.csv") as csvfile:
	spamreader = csv.DictReader(csvfile)
	i = 0
	for row in spamreader:
		for item in list_of:
			diction[item][row[item].lower()]=1
outfile = open("headphone_dict.json",'wb')

json.dump(diction,outfile)			